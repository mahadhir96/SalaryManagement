package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SweChallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SweChallengeApplication.class, args);
	}

}
